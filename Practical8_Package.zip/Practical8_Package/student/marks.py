def calculate_total(marks):
    return sum(marks)


def calculate_percentage(marks):
    total = calculate_total(marks)
    return total / len(marks)
