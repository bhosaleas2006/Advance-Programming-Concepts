def check_eligibility(attended, total):
    percentage = (attended / total) * 100

    if percentage >= 75:
        return True
    else:
        return False
