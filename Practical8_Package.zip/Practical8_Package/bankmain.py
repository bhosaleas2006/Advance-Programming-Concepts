from banking.account import create_account, get_balance
from banking.transaction import deposit, withdraw
from banking.loan import calculate_simple_interest

account = create_account("Adarsh", "1001", 10000)

print("Account Holder:", account["name"])
print("Account Number:", account["account_number"])
print("Initial Balance:", get_balance(account))

deposit(account, 5000)
print("After Deposit:", get_balance(account))

withdraw(account, 2000)
print("After Withdrawal:", get_balance(account))

interest, total = calculate_simple_interest(50000, 8, 2)

print("\n--- Loan Details ---")
print("Principal:", 50000)
print("Interest:", interest)
print("Total Amount:", total)
