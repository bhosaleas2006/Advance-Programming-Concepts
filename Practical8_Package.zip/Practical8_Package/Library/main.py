from books.book import add_book, display_book
from members.member import add_member, display_member
from transactions.transaction import issue_book, return_book

add_book("Python Programming")
display_book("Python Programming")

add_member("Amit")
display_member("Amit")

issue_book("Python Programming", "Amit")
return_book("Python Programming")