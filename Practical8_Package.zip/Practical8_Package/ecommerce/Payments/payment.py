def make_payment(amount):
    return f"Payment of Rs. {amount} successful"
