def track_order(order):
    return order["status"]
