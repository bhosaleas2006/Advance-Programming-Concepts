def calculate_simple_interest(principal, rate, years):
    interest = principal * rate * years / 100
    total = principal + interest

    return interest, total
