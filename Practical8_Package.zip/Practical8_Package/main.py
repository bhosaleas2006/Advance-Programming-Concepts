from Products.product import create_product
from Products.catalog import display_product

from Customers.customer import create_customer
from Customers.profile import display_customer

from Orders.order import create_order
from Orders.tracking import track_order

from Payments.payment import make_payment
from Payments.invoice import generate_invoice


# Create product
product = create_product("Laptop", 50000)

# Create customer
customer = create_customer("Adarsh", "adarsh@example.com")

# Display product
print("===== PRODUCT DETAILS =====")
display_product(product)

# Display customer
print("\n===== CUSTOMER DETAILS =====")
display_customer(customer)

# Create order
order = create_order(product, customer)

# Track order
print("\n===== ORDER DETAILS =====")
print("Order Status:", track_order(order))

# Make payment
print("\n===== PAYMENT DETAILS =====")
print(make_payment(product["price"]))

# Generate invoice
print("\n===== INVOICE =====")
print(generate_invoice(order))
