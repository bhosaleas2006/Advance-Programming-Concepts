from student.marks import calculate_total, calculate_percentage
from student.grade import calculate_grade
from student.attendance import check_eligibility

name = input("Enter student name: ")

marks = []

for i in range(3):
    mark = float(input(f"Enter marks for subject {i + 1}: "))
    marks.append(mark)

attended = int(input("Enter classes attended: "))
total_classes = int(input("Enter total classes: "))

total = calculate_total(marks)
percentage = calculate_percentage(marks)
grade = calculate_grade(percentage)
eligible = check_eligibility(attended, total_classes)

print("\n--- Student Report ---")
print("Name:", name)
print("Total Marks:", total)
print("Percentage:", percentage)
print("Grade:", grade)

if eligible:
    print("Attendance Status: Eligible")
else:
    print("Attendance Status: Not Eligible")
