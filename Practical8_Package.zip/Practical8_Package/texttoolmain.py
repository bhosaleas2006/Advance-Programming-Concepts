from texttools.cleaning import remove_punctuation, remove_extra_spaces
from texttools.tokenization import tokenize
from texttools.frequency import word_frequency

text = input("Enter text: ")

cleaned_text = remove_punctuation(text)
cleaned_text = remove_extra_spaces(cleaned_text)

words = tokenize(cleaned_text)
frequency = word_frequency(words)

print("\nCleaned Text:", cleaned_text)
print("Tokens:", words)
print("Word Frequency:", frequency)
