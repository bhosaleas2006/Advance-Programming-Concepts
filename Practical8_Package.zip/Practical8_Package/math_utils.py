from mathutils.basic import add, subtract, multiply, divide
from mathutils.number import is_prime, is_palindrome, is_armstrong
from mathutils.statistics import mean, maximum, minimum

a = 10
b = 5

print("Addition:", add(a, b))
print("Subtraction:", subtract(a, b))
print("Multiplication:", multiply(a, b))
print("Division:", divide(a, b))

n = 153

print("\nNumber:", n)
print("Prime:", is_prime(n))
print("Palindrome:", is_palindrome(n))
print("Armstrong:", is_armstrong(n))

numbers = [10, 20, 30, 40, 50]

print("\nStatistics")
print("Mean:", mean(numbers))
print("Maximum:", maximum(numbers))
print("Minimum:", minimum(numbers))
