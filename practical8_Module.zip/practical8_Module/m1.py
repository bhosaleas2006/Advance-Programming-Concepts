import calculate as c
print("Addition",c.add(10,20))
print("Subscription",c.sub(20,10))
print("Multiplication",c.mul(20,10))
print("Division",c.div(10,20))
