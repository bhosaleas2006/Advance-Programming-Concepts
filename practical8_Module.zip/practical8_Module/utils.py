from number_utils import is_prime, is_palindrome, is_armstrong, is_perfect

n = int(input("Enter a number: "))

if is_prime(n):
    print(n, "is a Prime number")
else:
    print(n, "is not a Prime number")

if is_palindrome(n):
    print(n, "is a Palindrome")
else:
    print(n, "is not a Palindrome")

if is_armstrong(n):
    print(n, "is an Armstrong number")
else:
    print(n, "is not an Armstrong number")

if is_perfect(n):
    print(n, "is a Perfect number")
else:
    print(n, "is not a Perfect number")
