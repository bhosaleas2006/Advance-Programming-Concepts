def total(m1,m2,m3):
    return m1 + m2 + m3
def per(m):
    return m /300 * 100
def grade(per):
    if per >= 90 :
        return "O"
    elif per >= 80:
        return "A"
    elif per >= 70:
        return "B"
    elif per >= 60:
        return "C"
    elif per >= 50:
        return "D"
    elif per >= 40:
        return "E"
    else:
        return "fail"
