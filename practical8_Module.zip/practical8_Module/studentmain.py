import student as s
m1=89
m2=98
m3 =60
total =total(m1,m2,m3)
print("Total :",total)
per =per(total)
print("percentage",per)
print("grade",grade(per))
