from recursive_utils import (
    factorial,
    fibonacci,
    sum_of_digits,
    decimal_to_binary
)

n = int(input("Enter a number: "))

print("Factorial:", factorial(n))
print("Fibonacci:", fibonacci(n))
print("Sum of digits:", sum_of_digits(n))
print("Binary:", decimal_to_binary(n))
