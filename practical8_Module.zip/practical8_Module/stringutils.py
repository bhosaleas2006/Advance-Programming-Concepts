from string_utils import (
    count_vowels,
    reverse_string,
    is_palindrome,
    count_words,
    remove_spaces
)

text = input("Enter a string: ")

print("Number of vowels:", count_vowels(text))
print("Reversed string:", reverse_string(text))

if is_palindrome(text):
    print("The string is a palindrome")
else:
    print("The string is not a palindrome")

print("Number of words:", count_words(text))
print("String without spaces:", remove_spaces(text))
