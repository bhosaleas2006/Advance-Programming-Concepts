def calculate_gross_salary(basic, hra, da):
    return basic + hra + da


def calculate_deductions(gross_salary, pf_rate=12):
    return gross_salary * pf_rate / 100


def calculate_net_salary(gross_salary, deductions):
    return gross_salary - deductions
