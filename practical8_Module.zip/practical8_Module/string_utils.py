def count_vowels(text):
    vowels = "aeiouAEIOU"
    count = 0

    for char in text:
        if char in vowels:
            count += 1

    return count


def reverse_string(text):
    return text[::-1]


def is_palindrome(text):
    text = text.lower().replace(" ", "")
    return text == text[::-1]


def count_words(text):
    return len(text.split())


def remove_spaces(text):
    return text.replace(" ", "")
