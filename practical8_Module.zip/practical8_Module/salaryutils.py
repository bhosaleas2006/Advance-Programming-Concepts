from salary_utils import (
    calculate_gross_salary,
    calculate_deductions,
    calculate_net_salary
)

basic = float(input("Enter basic salary: "))
hra = float(input("Enter HRA: "))
da = float(input("Enter DA: "))

gross = calculate_gross_salary(basic, hra, da)
deductions = calculate_deductions(gross)
net = calculate_net_salary(gross, deductions)

print("\n--- Salary Details ---")
print("Basic Salary:", basic)
print("HRA:", hra)
print("DA:", da)
print("Gross Salary:", gross)
print("Deductions:", deductions)
print("Net Salary:", net)
